module.exports = {
  reactStrictMode: true
}