module.exports = {
    node: {
        fs: 'empty'
      }
}